# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 17:07:29 2019

@author: Sunny Bangale
         Rahul Nalawade
"""

import spacy
from spacy_wordnet.wordnet_annotator import WordnetAnnotator 
import nltk
import sys
import os
import pysolr
import re
import json

from task1 import getNamedEntities
from task1 import getRoot
from task1 import lemmatize
from task1 import getPosWordMap

from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize

from nltk.stem import WordNetLemmatizer

lemmatizer = WordNetLemmatizer()

#question = ""

#Reads the questions from the given filepath and returns them as a list. 
#Preconditions: 
#   1. Each question must be grammatically correct. 
#   2. Each line must have a single question. 
def readQuestions(filepath):

    with open(filepath, 'r') as f:
        questions = [line.rstrip('\n') for line in f]

    return questions

#Function to derive Question Type
def questionType(question):

    question = str.lower(question)
    questionTokens = set()
    questionTokens.update(question.split())
            
    if "who" in questionTokens or "whom" in questionTokens:
        tempSet = set()
        tempSet.update(["PERSON", "ORG", "NORP"])
        return tempSet
    elif "when" in questionTokens:
        tempSet = set()
        tempSet.update(["DATE", "TIME", "EVENT", "DATETIME"])
        return tempSet
    elif "where" in questionTokens:
        tempSet = set()
        tempSet.update(["LOC", "GPE", "FAC", "EVENT"])
        return tempSet
    else:
        tempSet = set()
        tempSet.update(["UNKOWN"])
        return tempSet

#Function to print Question Information.
def questionInfo(question):
    #print("Q: \t\t", question)
    
    questionInfo = dict()

    questionInfo['Question'] = question
    
    qType = questionType(question)
    #print("Q Type: \t", questionType)
    questionInfo['Type'] = qType
    
    questionEntitiesList = getNamedEntities(nlp(question))
    #print("Q Entities: \t", questionEntitiesList)
    questionInfo['Entities'] = questionEntitiesList

    questionPosWordMap = getPosWordMap(nlp(question))
    #print("Q POS tags: \t", questionPosWordMap)
    questionInfo['POS_Tags'] = questionPosWordMap

    questionRoot = getRoot(nlp(question))
    questionInfo['Root'] = questionRoot
    #print("Q Root: \t", questionRoot)
    
    return questionInfo


def getQuestion():
    return question

#funtion to searc answer in Solr
def searchAnswerInSolr(qInfo):

    question = qInfo['Question']
    questionType = qInfo['Type'] 
    questionEntitiesList = qInfo['Entities']   
    questionWordPosMap = qInfo['POS_Tags'] 
    questionRoot = qInfo['Root'] 
    
    nlp = spacy.load("en_core_web_sm")
    
    #connect to solr Sentence Information core
    solrSentenceInformation = pysolr.Solr('http://localhost:8983/solr/SentenceInformationCore', always_commit = True, timeout=10)
    
    #conect to solr nlp core
    solrNLPCore = pysolr.Solr('http://localhost:8983/solr/NLPCore', always_commit = True, timeout=10)
    
    allCandidateSentences = list()
    
    #---------------- 1. Q-ENTITY-MATCHING ----------------
    # From all the sentences, here we take those sentences
    # having a match with the Named-Entities in the Question. 

    #print(questionEntitiesList)

    #search candidate sentences
    for tuple in questionEntitiesList:

        cleanedWord = re.sub(r'[^\w\s\'s]', ' ', tuple[0])
        results = solrNLPCore.search('Word:' + cleanedWord)   
        #print("Saw {0} result(s).".format(len(results)))
        
        for result in results:
            #iterate all intermediate results
            for r in result['SentenceList']:
                allCandidateSentences.append(r)
        #print()
    
    print(len(allCandidateSentences))
    
    #------------------------------------------------------
    #------------------------------------------------------
    # Removing stopwords form the lemmatized question
    #stop_words = set(stopwords.words('english')) 
    stop_words = spacy.lang.en.stop_words.STOP_WORDS

    doc = nlp(question)
    lemmatized_tokens = [token.lemma_ for token in doc]

    print(question)

    #print(lemmatized_tokens)

    filter1 = [w for w in lemmatized_tokens if not w in stop_words]

    #print("Filter 01: ", filter1)

    #------------------------------------------------------
    # Removing previously used entities from this list
    filter2 = []
    entity_names = []
    
    for tuple in questionEntitiesList:
        entity_names.append(tuple[0].split())
    #endFor
    #print("Entity Names: \t", entity_names)

    flat_list = []
    for sublist in entity_names:
        for item in sublist:
            flat_list.append(item)
    
    #print("Flat List: \t", flat_list)

    filter2 = [w for w in filter1 if not w in flat_list]

    #print("Filter 02: \t", filter2)

    filter3 = list()

    for w in filter2:
        if w != '?':
            filter3.append(w)
    #endFor

    print("Filter3: ", filter3)
    questionRootLemma = lemmatize(nlp(questionRoot))
    #filter3.append(questionRootLemma)
    print(type(filter3))

    filteringSet = set()

    filteringSet.update(filter3)
    
    

    print("\n----\n", filteringSet)

    #------------------------------------------------------
    #------------------------------------------------------
    
    
    probableAnswerDocs = list()
    probableAnswerList = list()
    probableAnswerSentences = list()
    
    #search answer from candidate sentences
    for sentence in allCandidateSentences:
        
        results = solrSentenceInformation.search('q = Id:' + sentence)
        #print("Saw {0} result(s).".format(len(results)))
       
        for result in results:
            
            coreId = result['Id']
            sentence = result['Sentence']    
            namedEntitiesSet = set()
            namedEntitiesSet.update(result['NamedEntities'])
            #print(coreId)
            #print(sentence[0])
            #print(namedEntitiesSet)
            sent_doc = nlp(sentence[0])
            lemmatized_sentence = [token.lemma_ for token in sent_doc]
            
            second_lemmatized_sentence = list()
            for word in lemmatized_sentence:
                second_lemmatized_sentence.append(word)

            lmSentSet = set()

            lmSentSet.update(second_lemmatized_sentence)

            #print("\n----\n", lmSentSet)

            if questionType.intersection(namedEntitiesSet):

                if filteringSet.intersection(lmSentSet):
                    probableAnswerSentences.append(sentence[0])
                    probableAnswerDocs.append(coreId[0])

    #print(probableAnswerList)    
    #print(probableAnswerDocs)
    print(probableAnswerSentences)
    
    #------------------------------------------------------
    '''
    answerList = list()
    answerDocs= list()
    answerSentences = list()
    
    #Filter answers based on root, lemma and pos tags
    for i in range(len(probableAnswerSentences)):
        sentenceRoot = getRoot(nlp(probableAnswerSentences[i]))
        questionRootLemma = lemmatize(nlp(questionRoot))
        sentenceRootLemma = lemmatize(nlp(sentenceRoot))
        
        if questionRoot == sentenceRoot or questionRootLemma == sentenceRootLemma:
            answerSentences.append(probableAnswerSentences[i])
            answerDocs.append(probableAnswerDocs[i])        
                        
    if len(answerSentences) > 0:
        print(answerSentences)
        print(answerDocs)
    else:
        #Apply POS method
        for i in range(len(probableAnswerSentences)):
            
            sentencePosWordMap = getPosWordMap(nlp(probableAnswerSentences[i]))
            
            if 'NOUN' in sentencePosWordMap and 'NOUN' in questionWordPosMap and sentencePosWordMap['NOUN'].intersection(questionWordPosMap['NOUN']):
                answerSentences.append(probableAnswerSentences[i])
                answerDocs.append(probableAnswerDocs[i])
            elif 'VERB' in sentencePosWordMap and 'VERB' in questionWordPosMap and sentencePosWordMap['VERB'].intersection(questionWordPosMap['VERB']):
                answerSentences.append(probableAnswerSentences[i])
                answerDocs.append(probableAnswerDocs[i])
                
        print(answerSentences)
        print(answerDocs)        
        #print('No answer found!') 
    '''

# Main function
if __name__ == '__main__':

    nlp = spacy.load("en_core_web_sm")
    
    #------------------- 1. DIRECTORIES -------------------
    # where test question resides
    testQuestionsPath = '../02-Project-Data/TestQuestions.txt'

    # where result would be stored for TASK-02
    resultDirectory = '../06-Results/Task-02/'

    #-------------- 2. QUESTION INFORMATION ---------------
    # reading the questions from the file. 
    questions = readQuestions(testQuestionsPath)

    # Stores the information about each question, iteratively
    qInfo = {}

    # Writing this Information about Questions in a file.
    f =  open(resultDirectory + 'QuestionInformation.txt', 'w')
    qIndex = 0
    # Iteratively extracting Question Information, for each question
    for q in questions: 
        qIndex += 1
        qInfo = questionInfo(q)
        #print(qInfo)
        f.write(str(qIndex)+ "\n")
        f.write(str(qInfo))
        #print(json.dumps(qInfo, ensure_ascii = False, indent = 4))
        f.write("\n-----------------------------------------------------------------------\n\n")

    #endFor
    f.close()

    #--------- 3. EXTRACTING CANDIDATE SENTENCES ----------
    '''
    q = questions[8]

    qInfo = questionInfo(q)
    #print(qInfo)

    searchAnswerInSolr(qInfo) 
    '''
    #------------------------------------------------------
    
    # Seaching for candidate sentences for each question:
    for q in questions: 
        qInfo = questionInfo(q)

        searchAnswerInSolr(qInfo)

        print("\n-----------------------------------------------------------------------\n\n")
    #endFor
    
    #------------------------------------------------------
    #Process question    
    #question = "Who founded Apple Inc.?"
    #question = "When was Apple Inc. founded?"
    #question = "When did Abraham Lincoln die?"
    #question = "Who founded Apple Inc.?"
    #question = "Where is Apple’s headquarters?"
    #question = "Where did Thomas Lincoln purchase farms?"
    #question = "Where is the headquarters of AT&T?"
    #question = "When did Steve Jobs die?"
    #question = "Where is Apple’s headquarters?"
    #question = "Who supported Apple in creating a new computing platform?"
    #question = "Where did Thomas Lincoln purchase farms?"
    #question = "Who supported Apple in creating a new computing platform?"
    #question = "Where was Melinda born?"
    
#The-End